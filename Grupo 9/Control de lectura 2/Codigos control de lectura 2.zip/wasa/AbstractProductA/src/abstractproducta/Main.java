/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abstractproducta;

/**
 *
 * @author PC
 */
public class Main {
    public static void main(String[] args) {
        AbstractFactory factory1 = new ConcreteFactory1();
        AbstractFactory factory2 = new ConcreteFactory2();

        AbstractProductA productA1 = factory1.createProductA();
        AbstractProductB productB1 = factory1.createProductB();
        AbstractProductA productA2 = factory2.createProductA();
        AbstractProductB productB2 = factory2.createProductB();

        System.out.println(productA1.usefulFunctionA());  
        System.out.println(productB1.usefulFunctionB());   
        System.out.println(productA2.usefulFunctionA());     
        System.out.println(productB2.usefulFunctionB());  
    }
}

