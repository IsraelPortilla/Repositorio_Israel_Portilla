/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abstractproducta;

/**
 *
 * @author PC
 */
class ConcreteProductB2 implements AbstractProductB {
    @Override
    public String usefulFunctionB() {
        return "funcion B2 del  producto  B";
    }
}

