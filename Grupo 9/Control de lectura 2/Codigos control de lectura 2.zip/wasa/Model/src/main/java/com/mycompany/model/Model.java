/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.model;

public class Model {
     String data;

    public Model() {
        this.data = "Hola, mundo!";
    }

    public String getData() {
        return data;
    }
}
