/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.model;

/**
 *
 * @author PC
 */
public class Singleton {
     static Singleton instance;
     String value;

     Singleton(String value) {
        this.value = value;
    }

    public static Singleton getInstance(String value) {
        if (instance == null) {
            instance = new Singleton(value);
        }
        return instance;
    }

    public String getValue() {
        return value;
    }

    public static void main(String[] args) {
        Singleton singleton1 = Singleton.getInstance("primer instancia");
        Singleton singleton2 = Singleton.getInstance("segunda instancia");

        System.out.println(singleton1.getValue());  
        System.out.println(singleton2.getValue());  
        System.out.println(singleton1 == singleton2);  
    }
}

