/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package product;

/**
 *
 * @author PC
 */
abstract class Product {
    public abstract String operation();
}

class ConcreteProductA extends Product {
    @Override
    public String operation() {
        return "Productob aperacion";
    }
}

class ConcreteProductB extends Product {
    @Override
    public String operation() {
        return "ProductoB operacion";
    }
}
