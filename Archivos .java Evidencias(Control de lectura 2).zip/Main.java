//Programa para instancias del objeto
public class Main {
  public static void main(String[] args) {
    soldado soldado1 = new soldado();
    soldado1.nombre = "Luis";
    soldado1.division = " infanteria de Marina";
    soldado1.registro();
    soldado1.servicio();
    armas arma1 = new armas();
    arma1.nombre1 = "AK-47";
    arma1.calibre = 47;
    arma1.uso();
    arma1.mantenimiento();
    cuartel cuartel1 = new cuartel();
    cuartel1.numero_soldados = 50;
    cuartel1.numero_cuartel = 13;
    cuartel1.formacion();
    cuartel1.despliegue();
    transporte transporte1 = new transporte();
    transporte1.numero_transporte = 4;
    transporte1.capacidad = 10;
    transporte1.traslado();
    transporte1.daño();
    guerra guerra1 = new guerra();
    guerra1.bajas_humanas = 37;
    guerra1.personal_vivo = 13;
    guerra1.desplazamiento();
    guerra1.ofensivas();
      }
    
}