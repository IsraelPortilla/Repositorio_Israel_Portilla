public class soldado{
    public String nombre;
    public String division;
    
    public void registro(){
        System.out.println("Soldado "+nombre+" pertenece a  la division"+division+".");
    }
     public void servicio(){
        System.out.println("Soldado "+nombre+" esta en mision activa actualmente");
    }
    
    
}