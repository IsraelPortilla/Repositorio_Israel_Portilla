public class cuartel{
public int numero_soldados;
public int numero_cuartel;
  public void formacion(){
    System.out.println("En el cuartel N° "+numero_cuartel+" hay "+numero_soldados+" soldados, se formaran en pelotones de 5 soldados para el despliegue");

  }
   public void despliegue(){
    System.out.println("Los pelotones se moveran en el campo de batalla en grupos de 5 pelotones");
    }

}