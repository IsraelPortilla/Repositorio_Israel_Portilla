public class armas{
    public String nombre1;
    public int calibre;
    
    public void uso(){
        System.out.println("Soldado Luis dispara un arma "+nombre1+" de calibre "+calibre+"mm como entrenamiento.");
    }
     public void mantenimiento(){
        System.out.println("El arma "+nombre1+" sera revisada, limpiada y probada antres de salir a la mision");
    }
}
    