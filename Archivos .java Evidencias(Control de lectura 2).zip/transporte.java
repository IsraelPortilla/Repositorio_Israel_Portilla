public class transporte{
    public int numero_transporte;
    public int capacidad;
    
    public void traslado(){
        System.out.println("El transporte N°"+numero_transporte+" lleva "+capacidad+" soldados del cuartel 13 a las cordenadas 0°13′12″S 78°30′45″O .");
    }
     public void daño(){
        System.out.println("El transporte N°"+numero_transporte+" resivio daños en sus ruedas perdiendo un peloton de los dos transportados.");
    }
}