public class guerra{
    public int bajas_humanas;
    public int personal_vivo;
    
    public void desplazamiento(){
        System.out.println("Se desplazo  a 0°13′12″S 78°30′45″O, 50 soldados del cuartel N°13, Luis pertenecea este grupo");
    }
     public void ofensivas(){
        System.out.println("La ofensiva del Dia D tiene "+bajas_humanas+" muertes y "+personal_vivo+" sobrevivientes y la ofensiva sigue.");
         
     }
}